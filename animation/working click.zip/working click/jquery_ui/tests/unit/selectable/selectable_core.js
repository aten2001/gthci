/*
 * selectable_core.js
 */